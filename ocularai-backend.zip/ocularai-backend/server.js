require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const app = express();

// Connexion DB
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Connection error:', err));

// Schéma Patient
const PatientSchema = new mongoose.Schema({
  name: { type: String, required: true },
  patientId: { type: String, required: true, unique: true },
  doctorNotes: String,
  images: [String],
  createdAt: { type: Date, default: Date.now }
});

const Patient = mongoose.model('Patient', PatientSchema);

// Middleware
app.use(cors());
app.use(express.json());

// Authentification Médecin
const authenticateDoctor = (req, res, next) => {
  if (req.headers.authorization !== `Bearer ${process.env.DOCTOR_SECRET}`) {
    return res.status(403).json({ error: 'Accès non autorisé' });
  }
  next();
};

// Routes
app.post('/api/patients', authenticateDoctor, async (req, res) => {
  try {
    const patient = new Patient(req.body);
    await patient.save();
    res.status(201).json(patient);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/patients/:id', async (req, res) => {
  try {
    const patient = await Patient.findOne({ patientId: req.params.id });
    if (!patient) return res.status(404).json({ error: 'Patient non trouvé' });
    res.json(patient);
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// Démarrer le serveur
app.listen(process.env.PORT, () => {
  console.log(`Server running on port ${process.env.PORT}`);
});